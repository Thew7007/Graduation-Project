package com.example.fullproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AttendPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attend_page);
    }
}