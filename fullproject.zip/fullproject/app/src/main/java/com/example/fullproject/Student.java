package com.example.fullproject;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Student extends AppCompatActivity {


    private EditText studentNameEdt, studentPhoneEdt, studentAddressEdt;
    private Button sendDatabtn;


    FirebaseDatabase firebaseDatabase;


    DatabaseReference databaseReference;


    StudentINFO studentInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);


        studentNameEdt = findViewById(R.id.idEdtStudentName);
        studentPhoneEdt = findViewById(R.id.idEdtStudentPhoneNumber);
        studentAddressEdt = findViewById(R.id.idEdtStudentAddress);


        firebaseDatabase = FirebaseDatabase.getInstance();


        databaseReference = firebaseDatabase.getReference("StudentInfo");


        studentInfo = new StudentINFO();

        sendDatabtn = findViewById(R.id.idBtnSendData);


        sendDatabtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String name = studentNameEdt.getText().toString();
                String phone = studentPhoneEdt.getText().toString();
                String address = studentAddressEdt.getText().toString();


                if (TextUtils.isEmpty(name) && TextUtils.isEmpty(phone) && TextUtils.isEmpty(address)) {

                    Toast.makeText(Student.this, "Please add some data.", Toast.LENGTH_SHORT).show();
                } else {

                    addDatatoFirebase(name, phone, address);
                }
            }
        });
    }

    private void addDatatoFirebase(String name, String phone, String address) {

        studentInfo.setEmployeeName(name);
        studentInfo.setEmployeeContactNumber(phone);
        studentInfo.setEmployeeAddress(address);


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                databaseReference.setValue(studentInfo);


                Toast.makeText(Student.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

                Toast.makeText(Student.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
