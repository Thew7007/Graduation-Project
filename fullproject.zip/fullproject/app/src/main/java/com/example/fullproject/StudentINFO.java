package com.example.fullproject;

public class StudentINFO {

    private String studentName;

    // string variable for storing
    // employee contact number
    private String studentContactNumber;

    // string variable for storing
    // employee address.
    private String studentAddress;

    // an empty constructor is
    // required when using
    // Firebase Realtime Database.
    public StudentINFO() {

    }

    // created getter and setter methods
    // for all our variables.
    public String getEmployeeName() {
        return studentName;
    }

    public void setEmployeeName(String employeeName) {
        this.studentName = employeeName;
    }

    public String getEmployeeContactNumber() {
        return studentContactNumber;
    }

    public void setEmployeeContactNumber(String employeeContactNumber) {
        this.studentContactNumber = employeeContactNumber;
    }

    public String getEmployeeAddress() {
        return studentAddress;
    }

    public void setEmployeeAddress(String employeeAddress) {
        this.studentAddress = employeeAddress;
    }
}
